"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useAuth } from "./auth-context"

export interface GeneratedImageItem {
  id: string
  image: string
  prompt: string
  aspectRatio: string
  createdAt: string
  userId: string
}

interface GalleryContextType {
  images: GeneratedImageItem[]
  addImage: (image: string, prompt: string, aspectRatio: string) => void
  deleteImage: (id: string) => void
  clearGallery: () => void
}

const GalleryContext = createContext<GalleryContextType | undefined>(undefined)

export function GalleryProvider({ children }: { children: ReactNode }) {
  const [images, setImages] = useState<GeneratedImageItem[]>([])
  const { user } = useAuth()

  useEffect(() => {
    if (user) {
      const storedImages = localStorage.getItem(`imageforge_gallery_${user.id}`)
      if (storedImages) {
        setImages(JSON.parse(storedImages))
      }
    } else {
      setImages([])
    }
  }, [user])

  const saveImages = (newImages: GeneratedImageItem[]) => {
    if (user) {
      localStorage.setItem(`imageforge_gallery_${user.id}`, JSON.stringify(newImages))
    }
  }

  const addImage = (image: string, prompt: string, aspectRatio: string) => {
    if (!user) return

    const newImage: GeneratedImageItem = {
      id: crypto.randomUUID(),
      image,
      prompt,
      aspectRatio,
      createdAt: new Date().toISOString(),
      userId: user.id,
    }

    const updatedImages = [newImage, ...images]
    setImages(updatedImages)
    saveImages(updatedImages)
  }

  const deleteImage = (id: string) => {
    const updatedImages = images.filter((img) => img.id !== id)
    setImages(updatedImages)
    saveImages(updatedImages)
  }

  const clearGallery = () => {
    setImages([])
    if (user) {
      localStorage.removeItem(`imageforge_gallery_${user.id}`)
    }
  }

  return (
    <GalleryContext.Provider value={{ images, addImage, deleteImage, clearGallery }}>
      {children}
    </GalleryContext.Provider>
  )
}

export function useGallery() {
  const context = useContext(GalleryContext)
  if (context === undefined) {
    throw new Error("useGallery must be used within a GalleryProvider")
  }
  return context
}

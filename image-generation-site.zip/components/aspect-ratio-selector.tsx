"use client"

import React from "react"

import { cn } from "@/lib/utils"

export type AspectRatio = "1:1" | "16:9" | "9:16"

interface AspectRatioSelectorProps {
  value: AspectRatio
  onChange: (ratio: AspectRatio) => void
}

const ratios: { value: AspectRatio; label: string; icon: React.ReactNode }[] = [
  {
    value: "1:1",
    label: "Quadrado",
    icon: (
      <div className="h-5 w-5 rounded-sm border-2 border-current" />
    ),
  },
  {
    value: "16:9",
    label: "Paisagem",
    icon: (
      <div className="h-3.5 w-6 rounded-sm border-2 border-current" />
    ),
  },
  {
    value: "9:16",
    label: "Retrato",
    icon: (
      <div className="h-6 w-3.5 rounded-sm border-2 border-current" />
    ),
  },
]

export function AspectRatioSelector({
  value,
  onChange,
}: AspectRatioSelectorProps) {
  return (
    <div className="flex flex-col gap-2">
      <label className="text-sm font-medium text-foreground">
        Proporcao da Imagem
      </label>
      <div className="flex gap-2">
        {ratios.map((ratio) => (
          <button
            key={ratio.value}
            onClick={() => onChange(ratio.value)}
            className={cn(
              "flex flex-1 flex-col items-center gap-2 rounded-xl border-2 p-3 transition-all duration-200",
              value === ratio.value
                ? "border-primary bg-primary/10 text-primary"
                : "border-border text-muted-foreground hover:border-primary/50 hover:text-foreground"
            )}
          >
            {ratio.icon}
            <span className="text-xs font-medium">{ratio.label}</span>
            <span className="text-[10px] opacity-70">{ratio.value}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

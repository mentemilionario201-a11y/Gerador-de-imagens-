"use client"

import { Textarea } from "@/components/ui/textarea"
import { Lightbulb } from "lucide-react"

interface PromptInputProps {
  value: string
  onChange: (value: string) => void
}

const examplePrompts = [
  "Um astronauta flutuando no espaco com a Terra ao fundo, estilo cinematografico",
  "Castelo medieval em uma montanha coberta de neve ao por do sol",
  "Gato samurai em armadura dourada, arte digital detalhada",
  "Floresta encantada com luzes magicas e criaturas fantasticas",
  "Cidade futurista cyberpunk com neons e carros voadores",
]

export function PromptInput({ value, onChange }: PromptInputProps) {
  const handleExampleClick = (prompt: string) => {
    onChange(prompt)
  }

  return (
    <div className="flex flex-col gap-3">
      <label className="text-sm font-medium text-foreground">
        Descreva sua imagem
      </label>
      <Textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Descreva em detalhes a imagem que voce quer criar. Seja especifico sobre cores, estilo, iluminacao, composicao..."
        className="min-h-[120px] resize-none border-border bg-card placeholder:text-muted-foreground focus-visible:ring-primary"
      />
      
      {/* Example Prompts */}
      <div className="rounded-lg border border-border bg-secondary/30 p-3">
        <div className="mb-2 flex items-center gap-2 text-xs font-medium text-muted-foreground">
          <Lightbulb className="h-3.5 w-3.5" />
          Exemplos de prompts
        </div>
        <div className="flex flex-wrap gap-2">
          {examplePrompts.map((prompt, index) => (
            <button
              key={index}
              type="button"
              onClick={() => handleExampleClick(prompt)}
              className="rounded-full bg-secondary px-3 py-1 text-xs text-secondary-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
            >
              {prompt.length > 40 ? `${prompt.substring(0, 40)}...` : prompt}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

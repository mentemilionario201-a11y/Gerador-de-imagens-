"use client"

import { Download, RefreshCw, Share2, Loader2, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import type { AspectRatio } from "./aspect-ratio-selector"

interface GeneratedImageProps {
  image: string | null
  isLoading: boolean
  aspectRatio: AspectRatio
  onRegenerate: () => void
}

export function GeneratedImage({
  image,
  isLoading,
  aspectRatio,
  onRegenerate,
}: GeneratedImageProps) {
  const aspectClass = {
    "1:1": "aspect-square",
    "16:9": "aspect-video",
    "9:16": "aspect-[9/16]",
  }[aspectRatio]

  const handleDownload = () => {
    if (!image) return
    const link = document.createElement("a")
    link.href = image
    link.download = `imageforge-${Date.now()}.png`
    link.click()
  }

  const handleShare = async () => {
    if (!image) return
    try {
      await navigator.share({
        title: "Imagem gerada com ImageForge AI",
        text: "Veja essa imagem que eu criei com IA!",
        url: window.location.href,
      })
    } catch {
      navigator.clipboard.writeText(window.location.href)
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-foreground">Resultado</h2>
        {image && !isLoading && (
          <div className="flex gap-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={onRegenerate}
              className="gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Regenerar
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={handleShare}
              className="gap-2"
            >
              <Share2 className="h-4 w-4" />
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={handleDownload}
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              Baixar
            </Button>
          </div>
        )}
      </div>

      <div
        className={cn(
          "relative flex w-full items-center justify-center overflow-hidden rounded-2xl border border-border bg-card",
          aspectClass,
          !image && !isLoading && "min-h-[300px]"
        )}
      >
        {isLoading ? (
          <div className="flex flex-col items-center gap-4">
            <div className="relative">
              <div className="absolute inset-0 animate-ping rounded-full bg-primary/30" />
              <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-primary/20">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            </div>
            <div className="text-center">
              <p className="text-sm font-medium text-foreground">
                Gerando sua imagem...
              </p>
              <p className="text-xs text-muted-foreground">
                Isso pode levar alguns segundos
              </p>
            </div>
          </div>
        ) : image ? (
          <img
            src={image || "/placeholder.svg"}
            alt="Imagem gerada"
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex flex-col items-center gap-4 p-8 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-secondary">
              <Sparkles className="h-8 w-8 text-muted-foreground" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">
                Sua imagem aparecera aqui
              </p>
              <p className="text-xs text-muted-foreground">
                Adicione referencias e clique em Gerar
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

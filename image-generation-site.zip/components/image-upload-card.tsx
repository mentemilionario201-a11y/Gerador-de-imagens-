"use client"

import React from "react"

import { useCallback, useState } from "react"
import { Upload, X, Sparkles, ImageIcon } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

interface ImageUploadCardProps {
  title: string
  description: string
  icon: React.ReactNode
  image: string | null
  onImageChange: (image: string | null) => void
  accentColor: string
}

export function ImageUploadCard({
  title,
  description,
  icon,
  image,
  onImageChange,
  accentColor,
}: ImageUploadCardProps) {
  const [isDragging, setIsDragging] = useState(false)

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragging(false)
      const file = e.dataTransfer.files[0]
      if (file && file.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (event) => {
          onImageChange(event.target?.result as string)
        }
        reader.readAsDataURL(file)
      }
    },
    [onImageChange]
  )

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0]
      if (file) {
        const reader = new FileReader()
        reader.onload = (event) => {
          onImageChange(event.target?.result as string)
        }
        reader.readAsDataURL(file)
      }
    },
    [onImageChange]
  )

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-2">
        <div
          className={cn(
            "flex h-8 w-8 items-center justify-center rounded-lg",
            accentColor
          )}
        >
          {icon}
        </div>
        <div>
          <h3 className="text-sm font-semibold text-foreground">{title}</h3>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
      </div>

      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={cn(
          "relative flex aspect-square w-full cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed transition-all duration-200",
          isDragging
            ? "border-primary bg-primary/10"
            : "border-border hover:border-primary/50 hover:bg-card/50",
          image && "border-solid border-primary/30"
        )}
      >
        {image ? (
          <>
            <img
              src={image || "/placeholder.svg"}
              alt={title}
              className="h-full w-full rounded-xl object-cover"
            />
            <Button
              variant="secondary"
              size="icon"
              className="absolute right-2 top-2 h-7 w-7 rounded-full bg-background/80 backdrop-blur-sm hover:bg-background"
              onClick={() => onImageChange(null)}
            >
              <X className="h-4 w-4" />
            </Button>
          </>
        ) : (
          <label className="flex h-full w-full cursor-pointer flex-col items-center justify-center gap-3 p-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-secondary">
              <Upload className="h-5 w-5 text-muted-foreground" />
            </div>
            <div className="text-center">
              <p className="text-sm font-medium text-foreground">
                Arraste uma imagem
              </p>
              <p className="text-xs text-muted-foreground">
                ou clique para selecionar
              </p>
            </div>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileInput}
              className="hidden"
            />
          </label>
        )}
      </div>
    </div>
  )
}

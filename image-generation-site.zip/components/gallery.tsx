"use client"

import { useState } from "react"
import { Download, Trash2, X, ZoomIn, Calendar, Maximize2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useGallery, type GeneratedImageItem } from "@/contexts/gallery-context"
import { cn } from "@/lib/utils"

interface GalleryProps {
  isOpen: boolean
  onClose: () => void
}

export function Gallery({ isOpen, onClose }: GalleryProps) {
  const { images, deleteImage, clearGallery } = useGallery()
  const [selectedImage, setSelectedImage] = useState<GeneratedImageItem | null>(null)
  const [filter, setFilter] = useState<"all" | "1:1" | "16:9" | "9:16">("all")

  if (!isOpen) return null

  const filteredImages = filter === "all" 
    ? images 
    : images.filter((img) => img.aspectRatio === filter)

  const handleDownload = (image: GeneratedImageItem) => {
    const link = document.createElement("a")
    link.href = image.image
    link.download = `imageforge-${image.id}.png`
    link.click()
  }

  const handleDelete = (id: string) => {
    deleteImage(id)
    if (selectedImage?.id === id) {
      setSelectedImage(null)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getAspectClass = (ratio: string) => {
    return {
      "1:1": "aspect-square",
      "16:9": "aspect-video",
      "9:16": "aspect-[9/16]",
    }[ratio] || "aspect-square"
  }

  return (
    <div className="fixed inset-0 z-50 flex">
      <div
        className="absolute inset-0 bg-background/90 backdrop-blur-md"
        onClick={onClose}
      />
      
      <div className="relative z-10 flex h-full w-full flex-col bg-background">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border px-6 py-4">
          <div>
            <h2 className="text-2xl font-bold text-foreground">Minha Galeria</h2>
            <p className="text-sm text-muted-foreground">
              {images.length} {images.length === 1 ? "imagem" : "imagens"} geradas
            </p>
          </div>
          <div className="flex items-center gap-4">
            {images.length > 0 && (
              <Button
                variant="destructive"
                size="sm"
                onClick={() => {
                  if (confirm("Tem certeza que deseja limpar toda a galeria?")) {
                    clearGallery()
                  }
                }}
              >
                Limpar tudo
              </Button>
            )}
            <button
              onClick={onClose}
              className="rounded-lg p-2 text-muted-foreground hover:bg-secondary hover:text-foreground"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 border-b border-border px-6 py-3">
          {(["all", "1:1", "16:9", "9:16"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "rounded-full px-4 py-1.5 text-sm font-medium transition-colors",
                filter === f
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              )}
            >
              {f === "all" ? "Todas" : f}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="flex-1 overflow-y-auto p-6">
          {filteredImages.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <div className="mb-4 rounded-full bg-secondary p-6">
                <ZoomIn className="h-12 w-12 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">
                {filter === "all" ? "Nenhuma imagem ainda" : `Nenhuma imagem ${filter}`}
              </h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {filter === "all"
                  ? "Comece a gerar imagens para ve-las aqui"
                  : "Tente outro filtro ou gere mais imagens"}
              </p>
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
              {filteredImages.map((image) => (
                <div
                  key={image.id}
                  className="group relative overflow-hidden rounded-xl border border-border bg-card transition-all hover:border-primary/50 hover:shadow-lg"
                >
                  <div className={cn("w-full overflow-hidden", getAspectClass(image.aspectRatio))}>
                    <img
                      src={image.image || "/placeholder.svg"}
                      alt={image.prompt}
                      className="h-full w-full object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 flex flex-col justify-between bg-gradient-to-t from-background/90 via-transparent to-transparent opacity-0 transition-opacity group-hover:opacity-100">
                    <div className="flex justify-end gap-1 p-2">
                      <button
                        onClick={() => setSelectedImage(image)}
                        className="rounded-lg bg-background/80 p-2 text-foreground backdrop-blur-sm hover:bg-background"
                      >
                        <Maximize2 className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="p-3">
                      <p className="mb-2 line-clamp-2 text-xs text-foreground">
                        {image.prompt}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          {formatDate(image.createdAt)}
                        </div>
                        <div className="flex gap-1">
                          <button
                            onClick={() => handleDownload(image)}
                            className="rounded-lg bg-primary p-1.5 text-primary-foreground hover:bg-primary/90"
                          >
                            <Download className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => handleDelete(image.id)}
                            className="rounded-lg bg-destructive p-1.5 text-destructive-foreground hover:bg-destructive/90"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Full Image Modal */}
      {selectedImage && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-background/95 backdrop-blur-lg">
          <button
            onClick={() => setSelectedImage(null)}
            className="absolute right-4 top-4 rounded-lg bg-secondary p-2 text-foreground hover:bg-secondary/80"
          >
            <X className="h-6 w-6" />
          </button>
          
          <div className="flex max-h-[90vh] max-w-[90vw] flex-col items-center gap-4">
            <img
              src={selectedImage.image || "/placeholder.svg"}
              alt={selectedImage.prompt}
              className="max-h-[70vh] rounded-xl object-contain"
            />
            <div className="max-w-2xl text-center">
              <p className="text-sm text-muted-foreground">{selectedImage.prompt}</p>
              <p className="mt-1 text-xs text-muted-foreground">
                {selectedImage.aspectRatio} - {formatDate(selectedImage.createdAt)}
              </p>
            </div>
            <div className="flex gap-3">
              <Button onClick={() => handleDownload(selectedImage)} className="gap-2">
                <Download className="h-4 w-4" />
                Baixar
              </Button>
              <Button
                variant="destructive"
                onClick={() => handleDelete(selectedImage.id)}
                className="gap-2"
              >
                <Trash2 className="h-4 w-4" />
                Excluir
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

import { experimental_generateImage } from "ai"

export const maxDuration = 60

export async function POST(request: Request) {
  try {
    const { prompt, aspectRatio } = await request.json()

    // Melhora o prompt para garantir resultados de alta qualidade
    const enhancedPrompt = `${prompt}. 
    
Style requirements: Photorealistic, ultra high definition, 8K resolution, professional photography, perfect composition, stunning lighting, masterpiece quality, intricate details, sharp focus, award-winning photography.`

    const sizeMap: Record<string, "1024x1024" | "1792x1024" | "1024x1792"> = {
      "1:1": "1024x1024",
      "16:9": "1792x1024",
      "9:16": "1024x1792",
    }

    const { image } = await experimental_generateImage({
      model: "openai/dall-e-3",
      prompt: enhancedPrompt,
      size: sizeMap[aspectRatio] || "1024x1024",
    })

    return Response.json({
      success: true,
      image: `data:image/png;base64,${image.base64}`,
    })
  } catch (error) {
    console.error("Error generating image:", error)
    return Response.json(
      {
        success: false,
        error: "Falha ao gerar imagem. Tente novamente.",
      },
      { status: 500 }
    )
  }
}

"use client"

import { useState, useCallback } from "react"
import { Sparkles, User, Mountain, Palette, Wand2, Info, LogIn, LogOut, ImageIcon, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ImageUploadCard } from "@/components/image-upload-card"
import { AspectRatioSelector, type AspectRatio } from "@/components/aspect-ratio-selector"
import { GeneratedImage } from "@/components/generated-image"
import { PromptInput } from "@/components/prompt-input"
import { AuthModal } from "@/components/auth-modal"
import { Gallery } from "@/components/gallery"
import { useAuth } from "@/contexts/auth-context"
import { useGallery } from "@/contexts/gallery-context"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function Home() {
  const [subjectImage, setSubjectImage] = useState<string | null>(null)
  const [sceneImage, setSceneImage] = useState<string | null>(null)
  const [styleImage, setStyleImage] = useState<string | null>(null)
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>("1:1")
  const [additionalPrompt, setAdditionalPrompt] = useState("")
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [showGallery, setShowGallery] = useState(false)
  const [currentPrompt, setCurrentPrompt] = useState("")

  const { user, logout, isLoading: authLoading } = useAuth()
  const { images, addImage } = useGallery()

  const buildPrompt = useCallback(() => {
    // Se o usuario digitou um prompt personalizado, use-o diretamente
    if (additionalPrompt.trim()) {
      return additionalPrompt.trim()
    }

    // Caso contrario, construa um prompt baseado nas imagens
    const parts: string[] = []

    if (subjectImage) {
      parts.push("featuring a detailed subject/character")
    }
    if (sceneImage) {
      parts.push("set in an immersive environment")
    }
    if (styleImage) {
      parts.push("with a distinctive artistic style")
    }

    if (parts.length > 0) {
      return `Create a stunning high-quality image ${parts.join(", ")}. Ultra detailed, professional photography, cinematic lighting, 8K resolution.`
    }

    return "Create a beautiful, high-quality artistic image with exceptional detail and professional composition."
  }, [subjectImage, sceneImage, styleImage, additionalPrompt])

  const handleGenerate = async () => {
    setIsLoading(true)
    try {
      const prompt = buildPrompt()
      setCurrentPrompt(prompt)

      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, aspectRatio }),
      })

      const data = await response.json()

      if (data.success) {
        setGeneratedImage(data.image)
        // Salvar na galeria se usuario estiver logado
        if (user) {
          addImage(data.image, prompt, aspectRatio)
        }
      } else {
        console.error("Generation failed:", data.error)
      }
    } catch (error) {
      console.error("Error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleRegenerate = () => {
    handleGenerate()
  }

  const hasAnyInput = subjectImage || sceneImage || styleImage || additionalPrompt.trim()

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent">
              <Sparkles className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">ImageForge AI</h1>
              <p className="text-xs text-muted-foreground">Gerador de Imagens com IA</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="gap-2">
              <Info className="h-4 w-4" />
              <span className="hidden sm:inline">Como usar</span>
            </Button>

            {user && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => setShowGallery(true)}
                className="gap-2"
              >
                <ImageIcon className="h-4 w-4" />
                <span className="hidden sm:inline">Galeria</span>
                {images.length > 0 && (
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                    {images.length}
                  </span>
                )}
              </Button>
            )}

            {authLoading ? (
              <div className="h-9 w-24 animate-pulse rounded-lg bg-secondary" />
            ) : user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="secondary" size="sm" className="gap-2">
                    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                    <span className="hidden sm:inline max-w-[100px] truncate">{user.name}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-medium text-foreground">{user.name}</p>
                    <p className="text-xs text-muted-foreground">{user.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setShowGallery(true)}>
                    <ImageIcon className="mr-2 h-4 w-4" />
                    Minha Galeria ({images.length})
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout} className="text-destructive">
                    <LogOut className="mr-2 h-4 w-4" />
                    Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button
                variant="default"
                size="sm"
                onClick={() => setShowAuthModal(true)}
                className="gap-2 bg-gradient-to-r from-primary to-accent"
              >
                <LogIn className="h-4 w-4" />
                <span className="hidden sm:inline">Entrar</span>
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8">
        {/* Hero Section */}
        <div className="mb-10 text-center">
          <h2 className="mb-3 text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-5xl">
            Crie imagens incriveis com IA
          </h2>
          <p className="mx-auto max-w-2xl text-pretty text-muted-foreground">
            Combine assunto, cena e estilo para gerar imagens unicas. Descreva sua visao detalhadamente e deixe a inteligencia artificial criar exatamente o que voce imaginou.
          </p>
          {!user && (
            <p className="mt-2 text-sm text-primary">
              Faca login para salvar suas imagens na galeria
            </p>
          )}
        </div>

        <div className="grid gap-8 lg:grid-cols-[1fr_1.2fr]">
          {/* Left Panel - Controls */}
          <div className="flex flex-col gap-6">
            {/* Upload Cards */}
            <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1 xl:grid-cols-3">
              <ImageUploadCard
                title="Assunto"
                description="Personagem principal"
                icon={<User className="h-4 w-4 text-primary-foreground" />}
                image={subjectImage}
                onImageChange={setSubjectImage}
                accentColor="bg-primary"
              />
              <ImageUploadCard
                title="Cena"
                description="Ambiente e local"
                icon={<Mountain className="h-4 w-4 text-accent-foreground" />}
                image={sceneImage}
                onImageChange={setSceneImage}
                accentColor="bg-accent"
              />
              <ImageUploadCard
                title="Estilo"
                description="Estetica visual"
                icon={<Palette className="h-4 w-4 text-chart-3" />}
                image={styleImage}
                onImageChange={setStyleImage}
                accentColor="bg-chart-3"
              />
            </div>

            {/* Aspect Ratio */}
            <AspectRatioSelector value={aspectRatio} onChange={setAspectRatio} />

            {/* Prompt Input */}
            <PromptInput value={additionalPrompt} onChange={setAdditionalPrompt} />

            {/* Generate Button */}
            <Button
              size="lg"
              onClick={handleGenerate}
              disabled={!hasAnyInput || isLoading}
              className="w-full gap-3 bg-gradient-to-r from-primary to-accent py-6 text-base font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-all hover:shadow-xl hover:shadow-primary/30 disabled:opacity-50"
            >
              <Wand2 className="h-5 w-5" />
              {isLoading ? "Gerando..." : "Gerar Imagem"}
            </Button>

            {/* Tips */}
            <div className="rounded-xl border border-border bg-card/50 p-4">
              <h4 className="mb-2 text-sm font-semibold text-foreground">
                Dicas para melhores resultados
              </h4>
              <ul className="space-y-1 text-xs text-muted-foreground">
                <li>Descreva detalhadamente o que voce quer ver na imagem</li>
                <li>Use termos como "alta qualidade", "8K", "cinematico"</li>
                <li>Especifique cores, iluminacao e estilo artistico</li>
                <li>Experimente diferentes proporcoes de imagem</li>
              </ul>
            </div>
          </div>

          {/* Right Panel - Generated Image */}
          <div className="lg:sticky lg:top-24 lg:self-start">
            <GeneratedImage
              image={generatedImage}
              isLoading={isLoading}
              aspectRatio={aspectRatio}
              onRegenerate={handleRegenerate}
            />

            {/* Current Prompt Display */}
            {generatedImage && currentPrompt && !isLoading && (
              <div className="mt-4 rounded-xl border border-border bg-card/50 p-4">
                <h4 className="mb-2 text-sm font-semibold text-foreground">Prompt utilizado</h4>
                <p className="text-xs text-muted-foreground">{currentPrompt}</p>
              </div>
            )}

            {/* Gallery Preview */}
            {user && images.length > 0 && (
              <div className="mt-4 rounded-xl border border-border bg-card/50 p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h4 className="text-sm font-semibold text-foreground">
                    Imagens recentes
                  </h4>
                  <button
                    onClick={() => setShowGallery(true)}
                    className="text-xs text-primary hover:underline"
                  >
                    Ver todas
                  </button>
                </div>
                <div className="flex gap-2 overflow-x-auto pb-2">
                  {images.slice(0, 5).map((img) => (
                    <button
                      key={img.id}
                      type="button"
                      onClick={() => setGeneratedImage(img.image)}
                      className="h-16 w-16 flex-shrink-0 overflow-hidden rounded-lg border border-border transition-all hover:border-primary hover:ring-2 hover:ring-primary/30"
                    >
                      <img
                        src={img.image || "/placeholder.svg"}
                        alt="Imagem gerada"
                        className="h-full w-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-16 border-t border-border bg-card/30">
        <div className="mx-auto max-w-7xl px-4 py-8">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              <span className="font-semibold text-foreground">ImageForge AI</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Powered by advanced AI models. Crie sem limites.
            </p>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
      <Gallery isOpen={showGallery} onClose={() => setShowGallery(false)} />
    </div>
  )
}
